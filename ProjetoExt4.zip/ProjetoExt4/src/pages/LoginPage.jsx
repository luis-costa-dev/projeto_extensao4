import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './LoginPage.css';

function LoginPage() {
  return (
    <div className="login-container">
      <header className="header site-container accent-bg">
        <div style={{display:'flex', alignItems:'center'}}>
          <Back />
          <div className="logo">🅱</div>
        </div>
        <nav className="nav">
          <Link to="/cadastro-alunos" className="btn register">
            Registrar
          </Link>
        </nav>
      </header>

      <main className="main">
        <h1>Login</h1>
        <div className="login-box">
          <label>Email</label>
          <input type="email" placeholder="Value" />

          <label>Senha</label>
          <input type="password" placeholder="Value" />

          <button className="submit-btn">Submit</button>
        </div>
      </main>

  <footer className="footer site-container accent-bg">
        <div className="footer-left">🅱</div>
        <div className="footer-middle">
          <div>
            <strong>Use cases</strong>
            <p>UI design</p>
            <p>UX design</p>
          </div>
          <div>
            <strong>Explore</strong>
            <p>Design</p>
            <p>Prototyping</p>
          </div>
          <div>
            <strong>Resources</strong>
            <p>Blog</p>
            <p>Best practices</p>
          </div>
        </div>
        <div className="footer-right">
          <span>📷</span>
          <span>🐦</span>
          <span>▶️</span>
          <span>🔗</span>
        </div>
      </footer>
    </div>
  );
}

export default LoginPage;

function Back(){
  const navigate = useNavigate();
  return (
    <button className="btn back-btn" onClick={() => navigate(-1)} aria-label="Voltar">← Voltar</button>
  )
}
