import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './CadastroAlunos.css';

function CadastroAlunos() {
  const [formData, setFormData] = useState({
    nome: '',
    cpf: '',
    email: '',
    deficiencia: '',
    descricao: '',
    arquivos: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Formulário cadastrado!\n' + JSON.stringify(formData, null, 2));
  };

  return (
    <div className="container">
      <header className="header site-container accent-bg">
        <div style={{display:'flex', alignItems:'center'}}>
          <Back />
          <div className="logo">🅱</div>
        </div>
        <nav className="nav">
          <button className="btn login">Login</button>
          <button className="btn register">Cadastrar</button>
        </nav>
      </header>

      <main className="main">
        <h1>Cadastro de Alunos</h1>
        <form className="form" onSubmit={handleSubmit}>
          <div className="form-left">
            <label>
              Nome
              <input
                type="text"
                name="nome"
                value={formData.nome}
                onChange={handleChange}
                placeholder="Nome completo"
              />
            </label>

            <label>
              CPF
              <input
                type="text"
                name="cpf"
                value={formData.cpf}
                onChange={handleChange}
                placeholder="CPF"
              />
            </label>

            <label>
              Email
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="Email"
              />
            </label>

            <label>
              Deficiência
              <input
                type="text"
                name="deficiencia"
                value={formData.deficiencia}
                onChange={handleChange}
                placeholder="Deficiência, se houver"
              />
            </label>

            <label>
              Descrição
              <textarea
                name="descricao"
                value={formData.descricao}
                onChange={handleChange}
                placeholder="Descrição adicional"
              />
            </label>

            <button type="submit" className="submit-btn">
              Cadastrar
            </button>
          </div>

          <div className="form-right">
            <label>Foto</label>
            <div className="photo-placeholder">
              <span>🖼️</span>
            </div>

            <label>
              Arquivos
              <textarea
                name="arquivos"
                value={formData.arquivos}
                onChange={handleChange}
                placeholder="Arquivos adicionais"
              />
            </label>
          </div>
        </form>
      </main>

  <footer className="footer site-container accent-bg">
        <div className="footer-left">🅱</div>
        <div className="footer-middle">
          <div>
            <strong>Use cases</strong>
            <p>UI design</p>
            <p>UX design</p>
          </div>
          <div>
            <strong>Explore</strong>
            <p>Design</p>
            <p>Prototyping</p>
          </div>
          <div>
            <strong>Resources</strong>
            <p>Blog</p>
            <p>Best practices</p>
          </div>
        </div>
        <div className="footer-right">
          <span>📷</span>
          <span>🐦</span>
          <span>▶️</span>
          <span>🔗</span>
        </div>
      </footer>
    </div>
  );
}

export default CadastroAlunos;

function Back(){
  const navigate = useNavigate();
  return <button className="btn back-btn" onClick={() => navigate(-1)}>← Voltar</button>
}
