import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Registrar.css';

const STORAGE_KEY = 'registrar-draft-v1';

export default function Registrar() {
	const navigate = useNavigate();
	const [email, setEmail] = useState('');
	const [name, setName] = useState('');
	const [password, setPassword] = useState('');
	const [status, setStatus] = useState('');
	const [saving, setSaving] = useState(false);

	// load draft
	useEffect(() => {
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (raw) {
				const obj = JSON.parse(raw);
				setEmail(obj.email || '');
				setName(obj.name || '');
				setPassword(obj.password || '');
			}
		} catch (err) { console.warn(err); }
	}, []);

	// autosave (debounced)
	useEffect(() => {
		setSaving(true);
		const t = setTimeout(() => {
			try {
				localStorage.setItem(STORAGE_KEY, JSON.stringify({ email, name, password }));
				setSaving(false);
			} catch (err) { console.warn(err); setSaving(false); }
		}, 700);
		return () => clearTimeout(t);
	}, [email, name, password]);

	const saveDraftNow = () => {
		try {
			localStorage.setItem(STORAGE_KEY, JSON.stringify({ email, name, password }));
			setStatus('Rascunho salvo localmente.');
			setTimeout(()=>setStatus(''), 2000);
		} catch (err) { console.warn(err); setStatus('Falha ao salvar rascunho.'); }
	};

	const clearDraft = () => {
		localStorage.removeItem(STORAGE_KEY);
		setEmail(''); setName(''); setPassword('');
		setStatus('Rascunho limpo.');
		setTimeout(()=>setStatus(''), 1500);
	};

	const validate = () => {
		if (!email.trim() || !name.trim() || !password) return 'Preencha todos os campos.';
		// simple email regex
		const emailRx = /^\S+@\S+\.\S+$/;
		if (!emailRx.test(email)) return 'Email inválido.';
		if (password.length < 6) return 'Senha deve ter pelo menos 6 caracteres.';
		return null;
	};

	const handleSubmit = async (e) => {
		e.preventDefault();
		const err = validate();
		if (err) { setStatus(err); return; }
		setStatus('Enviando...');
		try {
			const res = await fetch('/api/register', {
				method: 'POST', headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ email, name, password })
			});
			if (!res.ok) throw new Error('Erro no servidor');
			setStatus('Registro realizado com sucesso.');
			localStorage.removeItem(STORAGE_KEY);
			setTimeout(()=>{ navigate('/login'); }, 800);
		} catch (err) {
			console.warn(err);
			setStatus('Falha ao enviar. Rascunho salvo localmente.');
			try { localStorage.setItem(STORAGE_KEY, JSON.stringify({ email, name, password })); } catch(e){}
		}
	};

	return (
		<div className="registrar-page">
			<header className="header site-container accent-bg">
				<div style={{display:'flex', alignItems:'center'}}>
					<button className="back-btn" onClick={() => navigate(-1)} aria-label="Voltar">← Voltar</button>
					<div className="logo">🅱</div>
				</div>
			</header>

			<main className="main site-container">
				<section className="register-card card">
					<h1>Registrar</h1>
					<form onSubmit={handleSubmit} className="register-form">
						<label>Nome</label>
						<input type="text" value={name} onChange={e=>setName(e.target.value)} placeholder="Seu nome completo" />

						<label>Email</label>
						<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="seu@exemplo.com" />

						<label>Senha</label>
						<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Mínimo 6 caracteres" />

						<div className="actions">
							<button type="submit" className="btn primary">Criar conta</button>
							<button type="button" className="btn secondary" onClick={saveDraftNow}>{saving ? 'Salvando...' : 'Salvar rascunho'}</button>
							<button type="button" className="btn ghost" onClick={clearDraft}>Limpar</button>
						</div>

						{status && <div className="status">{status}</div>}
					</form>
				</section>
			</main>

			<footer className="footer site-container accent-bg">
				<div className="footer-left">🅱</div>
			</footer>
		</div>
	);
}
