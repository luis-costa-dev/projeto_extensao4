import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './notificacoes.css';

const STORAGE_KEY = 'notificacoes-v1';

function Notificacoes() {
  const [items, setItems] = useState([]);
  const [title, setTitle] = useState('');
  const [when, setWhen] = useState('');

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setItems(JSON.parse(raw));
    } catch (err) { console.warn(err); }
  }, []);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(items)); } catch (err) { console.warn(err); }
  }, [items]);

  const addItem = (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    const newItem = { id: Date.now(), title: title.trim(), when: when || new Date().toISOString().slice(0,10), read: false };
    setItems(prev => [newItem, ...prev]);
    setTitle(''); setWhen('');
  };

  const toggleRead = (id) => setItems(prev => prev.map(i => i.id === id ? {...i, read: !i.read} : i));
  const remove = (id) => setItems(prev => prev.filter(i => i.id !== id));

  return (
    <div className="notificacoes-page">
  <header className="header site-container accent-bg">
        <div style={{display:'flex', alignItems:'center'}}>
            <Back />
          <div className="logo">🅱</div>
        </div>
      </header>

      <main className="main site-container">
        <h1>Notificações e Lembretes</h1>

        <section className="new-reminder card">
          <h3>Criar lembrete</h3>
          <form onSubmit={addItem} className="reminder-form">
            <input placeholder="Texto do lembrete (ex.: Avaliar aluno X após 60 dias)" value={title} onChange={e=>setTitle(e.target.value)} />
            <div className="row">
              <input type="date" value={when} onChange={e=>setWhen(e.target.value)} />
              <button className="btn primary">Adicionar</button>
            </div>
          </form>
        </section>

        <section className="list-reminders">
          <h3>Lembretes</h3>
          {items.length === 0 && <p className="lead muted">Nenhum lembrete — crie um novo acima.</p>}

          <div className="reminder-list">
            {items.map(i => (
              <div key={i.id} className={`reminder card ${i.read? 'read' : ''}`}>
                <div className="reminder-left">
                  <div className="reminder-title">{i.title}</div>
                  <div className="reminder-when small muted">Agendado: {i.when}</div>
                </div>

                <div className="reminder-actions">
                  <button className="btn secondary" onClick={()=>toggleRead(i.id)}>{i.read? 'Marcar não lido' : 'Marcar lido'}</button>
                  <button className="btn danger" onClick={()=>remove(i.id)}>Excluir</button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>

  <footer className="footer site-container accent-bg">
        <div className="footer-left">🅱</div>
      </footer>
    </div>
  );
}

  function Back() {
    const navigate = useNavigate();
    return (
      <button className="back-btn" onClick={() => navigate(-1)} aria-label="Voltar">
        ← Voltar
      </button>
    );
  }
export default Notificacoes;
