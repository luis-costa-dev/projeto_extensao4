import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Relatorios.css';

const STORAGE_KEY = 'relatorios-v1';
const DRAFT_KEY = 'avaliacao-draft-v1';

function monthsBetween(start) {
  const a = new Date(start);
  const b = new Date();
  const months = (b.getFullYear() - a.getFullYear()) * 12 + (b.getMonth() - a.getMonth());
  return Math.max(0, months);
}

export default function Relatorios() {
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const [students, setStudents] = useState([]);
  const [status, setStatus] = useState('');

  // seed from stored relatorios or fallback to simple mock + any avaliacao draft
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        setStudents(JSON.parse(raw));
        return;
      }
      // try to seed from avaliacao-draft if present
      const draftRaw = localStorage.getItem(DRAFT_KEY);
      const seed = [];
      if (draftRaw) {
        try {
          const d = JSON.parse(draftRaw);
          if (d.name) seed.push({ id: Date.now(), name: d.name, evaluations: 1, marketStart: d.marketStart || new Date().toISOString().slice(0,10), lastEvaluation: new Date().toISOString().slice(0,10) });
        } catch(e){}
      }
      // small mock list
      const mock = [
        { id: 1, name: 'Ana Silva', evaluations: 3, marketStart: '2019-06-01', lastEvaluation: '2024-08-01' },
        { id: 2, name: 'Bruno Costa', evaluations: 1, marketStart: '2021-11-15', lastEvaluation: '2023-12-12' },
        { id: 3, name: 'Carla Sousa', evaluations: 2, marketStart: '2018-02-20', lastEvaluation: '2024-01-05' }
      ];
      const list = [...seed, ...mock];
      setStudents(list);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
    } catch (err) { console.warn(err); }
  }, []);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(students)); } catch(e){}
  }, [students]);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return students;
    return students.filter(s => s.name.toLowerCase().includes(term));
  }, [q, students]);

  const updateMarketStart = (id, date) => {
    setStudents(prev => prev.map(s => s.id === id ? {...s, marketStart: date } : s));
    setStatus('Alteração salva.');
    setTimeout(()=>setStatus(''), 1200);
  };

  const addMock = () => {
    const id = Date.now();
    const newS = { id, name: `Aluno ${id%1000}`, evaluations: 0, marketStart: new Date().toISOString().slice(0,10), lastEvaluation: '' };
    setStudents(prev => [newS, ...prev]);
  };

  const removeStudent = (id) => {
    if (!confirm('Remover este aluno dos relatórios?')) return;
    setStudents(prev => prev.filter(s => s.id !== id));
  };

  return (
    <div className="relatorios-page">
      <header className="header site-container accent-bg">
        <div style={{display:'flex', alignItems:'center'}}>
          <button className="back-btn" onClick={() => navigate(-1)} aria-label="Voltar">← Voltar</button>
          <div className="logo">🅱</div>
        </div>
      </header>

      <main className="main site-container">
        <h1>Relatórios de Avaliações</h1>

        <section className="controls row card">
          <input placeholder="Pesquisar por nome do aluno..." value={q} onChange={e=>setQ(e.target.value)} />
          <div className="actions">
            <button className="btn primary" onClick={addMock}>Adicionar mock</button>
            <button className="btn ghost" onClick={()=>{ setQ(''); }}>Limpar</button>
          </div>
        </section>

        <section className="results">
          {filtered.length === 0 && <p className="muted">Nenhum aluno encontrado.</p>}

          <div className="student-list">
            {filtered.map(s => {
              const months = s.marketStart ? monthsBetween(s.marketStart) : 0;
              const barW = Math.min(220, months * 2);
              return (
                <div key={s.id} className="student card">
                  <div className="student-left">
                    <div className="student-name">{s.name}</div>
                    <div className="small muted">Avaliações: {s.evaluations || 0} • Última: {s.lastEvaluation || '—'}</div>
                  </div>

                  <div className="student-mid">
                    <label>Entrada no mercado</label>
                    <input type="date" value={s.marketStart || ''} onChange={e=>updateMarketStart(s.id, e.target.value)} />
                    <div className="time-small">Tempo no mercado: <strong>{Math.floor(months/12)} anos {months%12} meses</strong></div>
                  </div>

                  <div className="student-right">
                    <svg width="240" height="40" className="mini-chart" role="img" aria-label={`Tempo no mercado ${months} meses`}>
                      <rect x="0" y="12" width="220" height="12" rx="6" fill="var(--bg-card)" />
                      <rect x="0" y="12" width="{barW}" height="12" rx="6" fill="var(--primary)" style={{width: barW}} />
                      <text x="4" y="28" fontSize="11" fill="#fff">{months} meses</text>
                    </svg>

                    <div className="student-actions">
                      <button className="btn secondary" onClick={()=>alert('Visualizar detalhes ainda não implementado')}>Detalhes</button>
                      <button className="btn danger" onClick={()=>removeStudent(s.id)}>Remover</button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {status && <div className="status-bar">{status}</div>}
      </main>

      <footer className="footer site-container accent-bg">
        <div className="footer-left">🅱</div>
      </footer>
    </div>
  );
}
