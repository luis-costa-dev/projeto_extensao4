import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './HomePage.css';
import estatisticasImage from '../assets/imagem.jpg'; // Importando a imagem

function HomePage() {
  const [notificationVisible, setNotificationVisible] = useState(true);

  const handleNotificationClose = () => {
    setNotificationVisible(false);
  };

  return (
    <div className="home-container">
      {/* Header com links de navegação */}
      <header className="header site-container accent-bg">
        <div style={{display:'flex', alignItems:'center'}}>
          <Back />
          <div className="logo">🅱</div>
        </div>
        <nav className="nav">
          <Link to="/cadastro-alunos">Cadastro de Alunos</Link>
          <Link to="/avaliacao">Avaliações de Alunos</Link>
          <Link to="/notificacoes">Notificações</Link>
          <Link to="/relatorios">Relatórios</Link>
          <Link to="/login">Login</Link>
          <Link to="/registrar">Registrar</Link>
        </nav>
      </header>

      {/* Notificação */}
      {notificationVisible && (
        <div className="notification">
          <p>Texto sobre notificação</p>
          <button className="btn-notify" onClick={handleNotificationClose}>
            Confirmar lido
          </button>
        </div>
      )}

      {/* Seção de Informações e Estatísticas */}
      <main className="main">
        <h1>Informações e Estatísticas</h1>
        <div className="stats-container">
          <img
            src={estatisticasImage}  // Usando a imagem importada
            alt="Gráfico de Estatísticas"
            className="stats-image"
          />
        </div>
      </main>

      {/* Rodapé */}
  <footer className="footer site-container accent-bg">
        <div className="footer-left">🅱</div>
        <div className="footer-middle">
          <div>
            <strong>Use cases</strong>
            <p>UI design</p>
            <p>UX design</p>
          </div>
          <div>
            <strong>Explore</strong>
            <p>Design</p>
            <p>Prototyping</p>
          </div>
          <div>
            <strong>Resources</strong>
            <p>Blog</p>
            <p>Best practices</p>
          </div>
        </div>
        <div className="footer-right">
          <span>📷</span>
          <span>🐦</span>
          <span>▶️</span>
          <span>🔗</span>
        </div>
      </footer>
    </div>
  );
}

export default HomePage;

function Back(){
  const navigate = useNavigate();
  return (
    <button className="btn back-btn" onClick={() => navigate(-1)} aria-label="Voltar">
      ← Voltar
    </button>
  )
}
