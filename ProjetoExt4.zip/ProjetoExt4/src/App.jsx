import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import CadastroAlunos from './pages/CadastroAlunos';
import Registrar from './pages/Registrar.jsx';
import AvaliacaoAlunos from './pages/AvaliacaoAlunos';
import Notificacoes from './pages/notificacoes';
import Relatorios from './pages/Relatorios';

function App() {
  return (
    <Router>
      <Routes>
        {/* Página Inicial */}
        <Route path="/" element={<HomePage />} />
        
        {/* Página de Login */}
        <Route path="/login" element={<LoginPage />} />

  {/* Página de Registrar (novo) */}
  <Route path="/registrar" element={<Registrar />} />

        {/* Página de Cadastro de Alunos */}
        <Route path="/cadastro-alunos" element={<CadastroAlunos />} />
  <Route path="/avaliacao" element={<AvaliacaoAlunos />} />
  <Route path="/notificacoes" element={<Notificacoes />} />
  <Route path="/relatorios" element={<Relatorios />} />
      </Routes>
    </Router>
  );
}

export default App;
